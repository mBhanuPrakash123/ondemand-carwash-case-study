import React from 'react'

const Order = () => {
    return (
        <div>
            <h1>You are in login page</h1>
        </div>
    )
}

export default Order
