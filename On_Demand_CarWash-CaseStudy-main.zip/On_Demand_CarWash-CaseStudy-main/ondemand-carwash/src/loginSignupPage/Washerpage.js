import React, {useEffect, useState} from 'react';
import './Navbar.css'
import './Home.css';
import { useNavigate } from 'react-router-dom';

const WasherPage = () => {
    return (
        <div>

            
        </div>
    )
}

export default WasherPage
